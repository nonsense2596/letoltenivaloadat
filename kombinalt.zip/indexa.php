﻿<html>
<head>
<link rel="stylesheet" href="bs/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="bs/js/bootstrap.min.js"></script>
<script src="jquery-3.3.1.min.js"></script>
</head>
<body>

<nav class="navbar navbar-light bg-primary">
  <a class="navbar-brand text-light">Linux sysinfo házi</a>
</nav>
<div class="row pt-5"></div>

<div class="container">
	<ul class="nav nav-tabs" id="myTab" role="tablist">
	  <li class="nav-item">
		<a class="nav-link active" id="tab1-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="true">General</a>
	  </li>
	  <li class="nav-item">
		<a class="nav-link" id="tab2-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab2" aria-selected="false">CPU</a>
	  </li>
	  <li class="nav-item">
		<a class="nav-link" id="tab3-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="tab3" aria-selected="false">Memory</a>
	  </li>
		<li class="nav-item">
		<a class="nav-link" id="tab4-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="tab4" aria-selected="false">Process info</a>
	  </li>
	</ul>
	<div class="tab-content" id="myTabContent">
	  <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab"></div>
	  <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab2-tab"></div>
	  <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab3-tab"></div>
	  <!--TAB4--><div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab4-tab"></div>
	</div>
</div>



<script>
// SCRIPT A TOP EREDMENYEINEK KIIRATASARA 10.151.104.21
setInterval(
function(){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		var splitResponse = xhr.responseText.split("\n");
		document.getElementById("tab4").innerHTML = "";
		for(i = 0; i < splitResponse.length; i++){
			document.getElementById("tab4").innerHTML += splitResponse[i] + "<br>";
		}
    }
  };
  xhr.open("POST", "asd.txt", true);
  xhr.send();
}, 1000);
</script>
<script>
$.ajax({url: "cpuinfo.php",type: "POST", cache: false}).done(function( html ) {
    $("#tab2").append(html);
});
$.ajax({url: "meminfo.php",type: "POST", cache: false}).done(function( html ) {
    $("#tab3").append(html);
});
$.ajax({url: "sysinfo.php",type: "POST", cache: false}).done(function( html ) {
    $("#tab1").append(html);
});
</script>
</body>

</html