﻿<?php
require('D:/Program Files (x86)/xampp/smarty/libs/Smarty.class.php');
// create object
$smarty = new Smarty;

$cpuinfo = cpuinfofunction();
function cpuinfofunction(){
	$handle = fopen("cpuinfo.txt", "r");
	$output = '';
	if ($handle) {
		while (($line = fgets($handle)) !== false) {
			$output .= $line;
			$output .= '<br>';
		}

		fclose($handle);
	} else {
	// let it fail silently
	}
	return $output;
}

$meminfo = memoryinfofunction();
function memoryinfofunction(){
	$handle = fopen("meminfo.txt", "r");
	$output = '';
	if ($handle) {
		while (($line = fgets($handle)) !== false) {
			$output .= $line;
			$output .= '<br>';
		}

		fclose($handle);
	} else {
	// let it fail silently
	}
	return $output;
}


// assign some content. This would typically come from
// a database or other source, but we'll use static
// values for the purpose of this example.
$smarty->assign('cpuinfo', $cpuinfo);
$smarty->assign('meminfo', $meminfo);
$smarty->assign('sysinfo', php_uname());




// display it
$smarty->display('index.tpl');

?>